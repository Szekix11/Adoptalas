<?php 
$itemModalSql = "SELECT * FROM `orders`";
$itemModalResult = mysqli_query($conn, $itemModalSql);

while($itemModalRow = mysqli_fetch_assoc($itemModalResult)){
    $orderid = $itemModalRow['orderId'];
    $userid = $itemModalRow['userId'];
    $orderStatus = $itemModalRow['orderStatus'];
?>

<!-- Modal -->
<div class="modal fade" id="orderStatus<?php echo $orderid; ?>" tabindex="-1" role="dialog" aria-labelledby="orderStatus<?php echo $orderid; ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(111 202 203);">
                <h5 class="modal-title" id="orderStatus<?php echo $orderid; ?>">Örökbefogadás státuszok és részletek</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="partials/_orderManage.php" method="post" style="border-bottom: 2px solid #dee2e6;">
                    <div class="text-left my-2">    
                        <b><label for="name">Örökbefogadás státusz</label></b>
                        <div class="row mx-2">
                            <input class="form-control col-md-3" id="status" name="status" value="<?php echo $orderStatus; ?>" type="number" min="0" max="6" required>    
                            <button type="button" class="btn btn-secondary ml-1" data-container="body" data-toggle="popover" title="Státuszok" data-placement="bottom" data-html="true" data-content="0= Állat kiválasztva.<br> 1=Alkalmassági ellenőrzés folyamatban.<br> 2=Örökbefogadás jóváhagyva.<br> 3=Örökbeadás folyamatban!<br> 4=Örökbeadás befejezve.<br> 5=Örökbefogadás elutasítva.<br> 6=Visszavonás.">
                                <i class="fas fa-info"></i>
                            </button>
                        </div>
                    </div>
                    <input type="hidden" id="orderId" name="orderId" value="<?php echo $orderid; ?>">
                    <button type="submit" class="btn btn-success mb-2" name="updateStatus">Frissítés</button>
                </form>
                <?php 
                    $deliveryDetailSql = "SELECT * FROM `deliverydetails` WHERE `orderId`= $orderid";
                    $deliveryDetailResult = mysqli_query($conn, $deliveryDetailSql);
                    
                    if($deliveryDetailResult) {
                        $deliveryDetailRow = mysqli_fetch_assoc($deliveryDetailResult);
                        $trackId = isset($deliveryDetailRow['id']) ? $deliveryDetailRow['id'] : null;
                        $deliveryBoyName = isset($deliveryDetailRow['deliveryBoyName']) ? $deliveryDetailRow['deliveryBoyName'] : '';
                        $deliveryBoyPhoneNo = isset($deliveryDetailRow['deliveryBoyPhoneNo']) ? $deliveryDetailRow['deliveryBoyPhoneNo'] : '';

                        if($orderStatus > 0 && $orderStatus < 5) { 
                ?>
                            <form action="partials/_orderManage.php" method="post">
                                <div class="text-left my-2">
                                    <b><label for="name">Gondozó/ügyintéző neve:</label></b>
                                    <input class="form-control" id="name" name="name" value="<?php echo $deliveryBoyName; ?>" type="text" required>
                                </div>
                                <div class="text-left my-2 row">
                                    <div class="form-group col-md-6">
                                        <b><label for="phone">Telefonszám:</label></b>
                                        <input class="form-control" id="phone" name="phone" value="<?php echo $deliveryBoyPhoneNo; ?>" type="tel" required pattern="[0-9]{9}">
                                    </div>
                                </div>
                                <input type="hidden" id="trackId" name="trackId" value="<?php echo $trackId; ?>">
                                <input type="hidden" id="orderId" name="orderId" value="<?php echo $orderid; ?>">
                                <button type="submit" class="btn btn-success" name="updateDeliveryDetails">Frissítés</button>
                            </form>
                <?php 
                        }
                    } else {
                        echo 'Error fetching delivery details: ' . mysqli_error($conn);
                    }
                ?>
            </div>
        </div>
    </div>
</div>

<?php
    }
?>

<style>
    .popover {
        top: -77px !important;
    }
</style>

<script>
    $(function () {
        $('[data-toggle="popover"]').popover();
    });
</script>
