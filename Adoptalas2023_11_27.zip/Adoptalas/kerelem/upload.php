<?php
include '_dbconnect.php'; // Az adatbázis kapcsolat beállítása, ha még nincs

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadDir = "uploads/"; // A feltöltött fájlok tárolási mappája
    $allowedExtensions = array("pdf", "doc", "docx"); // Elfogadott fájltípusok

    $fileName = $_FILES['file']['name'];
    $fileSize = $_FILES['file']['size'];
    $fileTmpName  = $_FILES['file']['tmp_name'];
    $fileType = $_FILES['file']['type'];

    // Ellenőrzés: Elfogadott fájltípus és nem túl nagy méretű
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    if (in_array($fileExtension, $allowedExtensions) && $fileSize < 2097152) { // 2 MB méretkorlát

        // A fájl elmentése a kiválasztott könyvtárba
        $uploadPath = $uploadDir . basename($fileName);
        move_uploaded_file($fileTmpName, $uploadPath);

        // Adatbázisba mentés
        $sql = "INSERT INTO uploaded_files (file_name, file_path) VALUES ('$fileName', '$uploadPath')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            echo "A fájl sikeresen feltöltve és az adatbázisba mentve.";
        } else {
            echo "Hiba az adatbázisba mentés során: " . mysqli_error($conn);
        }

    } else {
        echo "Hiba: Érvénytelen fájltípus vagy túl nagy fájlméret.";
    }
}
?>
