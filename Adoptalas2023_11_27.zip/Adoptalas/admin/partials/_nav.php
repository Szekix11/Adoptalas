     <!-- Header tartalom -->
    <header class="header" id="header">
        <div class="header__toggle">
            <i class='bx bx-menu' id="header-toggle"></i>
        </div>
        
        <div class="header__img">
            <img src="assetsForSideBar/img/perfil.jpg" alt="">
        </div>
    </header>

    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div>
                <a href="index.php" class="nav__logo">
                    <i class='bx bx-layer nav__logo-icon'></i>
                    <span class="nav__logo-name">Állati Otthon admin</span>
                </a>
              <!-- Navigációs menüpontok -->
                <div class="nav__list">
                    
                    <a href="index.php?page=orderManage" class="nav-orderManage nav__link ">
                      <i class='bx bx-bar-chart-alt-2 nav__icon' ></i>
                      <span class="nav__name">Örökbefogadások</span>
                    </a>
                    <a href="index.php?page=categoryManage" class="nav__link nav-categoryManage">
                      <i class='bx bx-folder nav__icon' ></i>
                      <span class="nav__name">Kategóriák</span>
                    </a>
                    <a href="index.php?page=menuManage" class="nav__link nav-menuManage">
                      <i class='bx bx-message-square-detail nav__icon' ></i>
                      <span class="nav__name">Menü</span>
                    </a>
                 
                    <a href="index.php?page=userManage" class="nav__link nav-userManage">
                      <i class='bx bx-user nav__icon' ></i>
                      <span class="nav__name">Felhasználók</span>
                    </a>
                    <a href="index.php?page=siteManage" class="nav__link nav-siteManage">
                      <i class="fas fa-cogs"></i>
                      <span class="nav__name">Oldal beállítások</span>
                    </a>
                </div>
            </div>
            <!-- Kijelentkezési menüpont -->

            <a href="partials/_logout.php" class="nav__link">
              <i class='bx bx-log-out nav__icon' ></i>
              <span class="nav__name">Kijelentkezés</span>
            </a>
        </nav>
    </div>  
    
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>

    <?php $page = isset($_GET['page']) ? $_GET['page'] :'home'; 
    /* <?php $page = isset($_GET['page']) ? $_GET['page'] :'home'; ?>: Ez a PHP kód részlet az aktuális oldal nevét (az URL-ben található page változót) menti a 
    $page nevű változóba. Ha az URL nem tartalmaz page változót, vagy ha az üres, akkor alapértelmezettként "home" értéket rendel a $page változóhoz.

    $('.nav-<?php echo $page; ?>').addClass('active'): Ez a JavaScript kód részlet jQuery segítségével kiválasztja 
    azt a navigációs menüpontot, amely az aktuális oldalt reprezentálja. Az aktuális oldalt a $page PHP változóból kapja meg. Ezután 
    az "active" osztályt hozzáadja ehhez a navigációs menüponthoz.*/ 
    
    
    ?>
	  $('.nav-<?php echo $page; ?>').addClass('active')

    
</script>
   