<?php
    include '_dbconnect.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['updateDetail'])) {
        $name = $_POST["name"];



        $sql = "UPDATE `sitedetail` SET systemName = '$name' WHERE tempId = 1";   
        $result = mysqli_query($conn, $sql);

        
        if($result){
            echo "<script>alert('Sikeresen megváltoztattad az oldal nevét');
                window.location=document.referrer;
                </script>";
        }    
    }
    
}
?>