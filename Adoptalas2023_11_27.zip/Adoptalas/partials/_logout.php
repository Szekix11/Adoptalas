<?php

session_start();
echo "Kijelentkezés folyamatban kérlek várj";
unset($_SESSION["loggedin"]);
unset($_SESSION["username"]);
unset($_SESSION["userId"]);



header("location: /Adoptalas/index.php");
?>