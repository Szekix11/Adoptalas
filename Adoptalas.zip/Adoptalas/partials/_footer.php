<div class="footer container-fluid bg-dark text-light">
    <p class="text-center py-2 mb-0">SZTE JGYPK Szerveroldali programozás 2023 <a href="https://hu.wikipedia.org/wiki/%C3%96r%C3%B6kbefogad%C3%A1s#Az_1959._%C3%A9vi_IV._t%C3%B6rv%C3%A9nyben" target="_blank" rel="noopener noreferrer">Örökbefogadás wiki</a></p>
</div>
