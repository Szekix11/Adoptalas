<?php
    include '_dbconnect.php'; // Adatbázis kapcsolat betöltése

if($_SERVER["REQUEST_METHOD"] == "POST") { // Ellenőrzi, hogy a kérés POST kérés-e
// Ellenőrzi, hogy a POST kérés tartalmazza-e a 'contactReply' nevű űrlapot
    if(isset($_POST['contactReply'])) {
        $contactId = $_POST['contactId'];
        $message = $_POST['message'];
        $userId = $_POST['userId'];
        
        $sql = "INSERT INTO `contactreply` (`contactId`, `userId`, `message`, `datetime`) VALUES ('$contactId', '$userId', '$message', current_timestamp())";   
        $result = mysqli_query($conn, $sql);
        if($result) {
            echo "<script>alert('Siekres');
                    window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('Hiba);
                    window.location=document.referrer;
                </script>";
        }
    }
}
?>