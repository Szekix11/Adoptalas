<?php
    include '_dbconnect.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['createItem'])) {
        $name = $_POST["name"];
        $description = $_POST["description"];
        $categoryId = $_POST["categoryId"];
        $price = $_POST["price"];

        $sql = "INSERT INTO `animals` (`animalsName`, `animalsPrice`, `animalsDesc`, `animalsCategorieId`, `animalsPubDate`) VALUES ('$name', '$price', '$description', '$categoryId', current_timestamp())";   
        $result = mysqli_query($conn, $sql);
        $animalsId = $conn->insert_id;
        if ($result){
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check !== false) {
                
                $newName = 'animals-'.$animalsId;
                $newfilename=$newName .".jpg";

                $uploaddir = $_SERVER['DOCUMENT_ROOT'].'/Adoptalas/img/';
                $uploadfile = $uploaddir . $newfilename;

                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {
                    echo "<script>alert('Sikeres');
                            window.location=document.referrer;
                        </script>";
                } else {
                    echo "<script>alert('Hiba');
                            window.location=document.referrer;
                        </script>";
                }

            }
            else{
                echo '<script>alert("Kérlek tölts fel képet.");
                        window.location=document.referrer;
                    </script>';
            }
        }
        else {
            echo "<script>alert('Hiba');
                    window.location=document.referrer;
                </script>";
        }
    }
    if(isset($_POST['removeItem'])) {
        $animalsId = $_POST["animalsId"];
        $sql = "DELETE FROM `animals` WHERE `animalsId`='$animalsId'";   
        $result = mysqli_query($conn, $sql);
        $filename = $_SERVER['DOCUMENT_ROOT']."/Adoptalas/img/animals-".$animalsId.".jpg";
        if ($result){
            if (file_exists($filename)) {
                unlink($filename);
            }
            echo "<script>alert('Törölve');
                window.location=document.referrer;
            </script>";
        }
        else {
            echo "<script>alert('Hiba');
            window.location=document.referrer;
            </script>";
        }
    }
    if(isset($_POST['updateItem'])) {
        $animalsId = $_POST["animalsId"];
        $animalsName = $_POST["name"];
        $animalsDesc = $_POST["desc"];
        $animalsPrice = $_POST["price"];
        $animalsCategorieId = $_POST["catId"];

        $sql = "UPDATE `animals` SET `animalsName`='$animalsName', `animalsPrice`='$animalsPrice', `animalsDesc`='$animalsDesc', `animalsCategorieId`='$animalsCategorieId' WHERE `animalsId`='$animalsId'";   
        $result = mysqli_query($conn, $sql);
        if ($result){
            echo "<script>alert('Frissítés');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('hiba');
                window.location=document.referrer;
                </script>";
        }
    }
    if(isset($_POST['updateItemPhoto'])) {
        $animalsId = $_POST["animalsId"];
        $check = getimagesize($_FILES["itemimage"]["tmp_name"]);
        if($check !== false) {
            $newName = 'animals-'.$animalsId;
            $newfilename=$newName .".jpg";

            $uploaddir = $_SERVER['DOCUMENT_ROOT'].'/Adoptalas/img/';
            $uploadfile = $uploaddir . $newfilename;

            if (move_uploaded_file($_FILES['itemimage']['tmp_name'], $uploadfile)) {
                echo "<script>alert('Sikeres');
                        window.location=document.referrer;
                    </script>";
            } else {
                echo "<script>alert('Hiba');
                        window.location=document.referrer;
                    </script>";
            }
        }
        else{
            echo '<script>alert("Kérlek tölts fel képet");
            window.location=document.referrer;
                </script>';
        }
    }
}
?>