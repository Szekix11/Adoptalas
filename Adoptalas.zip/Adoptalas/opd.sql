-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Okt 23. 02:24
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `opd`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `categories`
--

CREATE TABLE `categories` (
  `categorieId` int(12) NOT NULL,
  `categorieName` varchar(255) NOT NULL,
  `categorieDesc` text NOT NULL,
  `categorieCreateDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `categories`
--

INSERT INTO `categories` (`categorieId`, `categorieName`, `categorieDesc`, `categorieCreateDate`) VALUES
(1, 'Kutya', 'A legjobb barátok. A kutya az ember leghűségesebb társa. Kedvenc négylábú kutyáink különböző méretűek és fajtájúak, de mindegyikük imádnivaló és várja, hogy egy szerető otthonba kerüljön.', '2023-10-04 00:00:00'),
(2, 'Macska', 'Cica, cica, cica! Különböző macska fajták várják, hogy otthonra találjanak. Legyen szőrös barátja, és élvezze a macskák társaságát. Mindegyik macska egyedi személyiséggel rendelkezik, és hűséges társa lehet.', '2023-10-04 00:00:00'),
(3, 'Tengerimalac', 'Az aranyos tengerimalacok elképesztő háziállatok. Egyéni karakterek, és vidám hangulatuk mindennapokat vidámabbá tesz. Fogadjon örökbe egy tengerimalacot, és élvezze a cukiságukat.', '2023-10-04 00:00:00'),
(4, 'Nyúl', 'A nyulak csendes és bájos háziállatok. Sokféle nyúlfajta közül választhat, és mindegyikük hűséges társ lehet. A nyúlok ápolása és etetése egyszerű, és örömüket leli a játékban.', '2023-10-04 00:00:00'),
(5, 'Madár', 'A madarak csodálatos és színes lények. Legyen szárnyas barátja, és hallgassa meg éneküket minden nap. A különböző madárfajták szépségükkel és egyediségükkel elvarázsolják majd önt.', '2023-10-04 00:00:00'),
(6, 'Kisemlős', 'Az apró kisemlősök különleges örömet hoznak az otthonába. Például hörcsögök, patkányok és csincsillák szép, kis háziállatok lehetnek. Találja meg a tökéletes kisemlőst, hogy elkényeztesse őket.', '2023-10-04 00:00:00'),
(7, 'Reptília', 'A hüllők és kétéltűek különleges háziállatok. Például gyíkok, teknősök és békák elképesztőek. A különböző fajták eltérő igényekkel rendelkeznek, de mind közül valódi ritkaságok.', '2023-10-04 00:00:00'),
(8, 'Egyéb', 'Nem csak a hagyományos háziállatok érnek, sok más különleges és szokatlan állat is várja, hogy örökbefogadják őket. Fedezze fel a különleges állatok világát, és találja meg a saját különleges társát.', '2023-10-04 00:00:00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contact`
--

CREATE TABLE `contact` (
  `contactId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `orderId` int(21) NOT NULL DEFAULT 0 COMMENT 'If problem is not related to the order then order id = 0',
  `message` text NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contact`
--

INSERT INTO `contact` (`contactId`, `userId`, `email`, `phoneNo`, `orderId`, `message`, `time`) VALUES
(1, 2, 'szekix16@gmail.com', 5362517622, 1, 'Romlott volt a sajt.', '2023-10-04 15:04:17');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contactreply`
--

CREATE TABLE `contactreply` (
  `id` int(21) NOT NULL,
  `contactId` int(21) NOT NULL,
  `userId` int(23) NOT NULL,
  `message` text NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contactreply`
--

INSERT INTO `contactreply` (`id`, `contactId`, `userId`, `message`, `datetime`) VALUES
(4, 1, 2, '500 ft kupon', '2023-10-08 23:36:21');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `deliverydetails`
--

CREATE TABLE `deliverydetails` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `deliveryBoyName` varchar(35) NOT NULL,
  `deliveryBoyPhoneNo` bigint(25) NOT NULL,
  `deliveryTime` int(200) NOT NULL COMMENT 'Time in minutes',
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `deliverydetails`
--

INSERT INTO `deliverydetails` (`id`, `orderId`, `deliveryBoyName`, `deliveryBoyPhoneNo`, `deliveryTime`, `dateTime`) VALUES
(1, 1, 'Dorián', 7036056778, 60, '2023-10-17 22:56:40');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `pizzaId` int(21) NOT NULL,
  `itemQuantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `orderitems`
--

INSERT INTO `orderitems` (`id`, `orderId`, `pizzaId`, `itemQuantity`) VALUES
(1, 1, 21, 7),
(2, 1, 30, 8),
(3, 1, 15, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orders`
--

CREATE TABLE `orders` (
  `orderId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipCode` int(21) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `amount` int(200) NOT NULL,
  `paymentMode` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=cash on delivery, \r\n1=online ',
  `orderStatus` enum('0','1','2','3','4','5','6') NOT NULL DEFAULT '0' COMMENT '0=Order Placed.\r\n1=Order Confirmed.\r\n2=Preparing your Order.\r\n3=Your order is on the way!\r\n4=Order Delivered.\r\n5=Order Denied.\r\n6=Order Cancelled.',
  `orderDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `orders`
--

INSERT INTO `orders` (`orderId`, `userId`, `address`, `zipCode`, `phoneNo`, `amount`, `paymentMode`, `orderStatus`, `orderDate`) VALUES
(1, 2, 'Szeged, Erős utca 5', 232323, 3334434232, 38711, '0', '3', '2023-10-04 15:54:28');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pizza`
--

CREATE TABLE `pizza` (
  `pizzaId` int(12) NOT NULL,
  `pizzaName` varchar(255) NOT NULL,
  `pizzaPrice` int(12) NOT NULL,
  `pizzaDesc` text NOT NULL,
  `pizzaCategorieId` int(12) NOT NULL,
  `pizzaPubDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `pizza`
--

INSERT INTO `pizza` (`pizzaId`, `pizzaName`, `pizzaPrice`, `pizzaDesc`, `pizzaCategorieId`, `pizzaPubDate`) VALUES
(1, 'Golden Retriever', 1200, 'A Golden Retrieverek a legjobb barátok. Ők az ember legállhatatosabb társai. Kiváló házőrzők és játékos, vidám kutyák.', 1, '2023-10-04 00:00:00'),
(2, 'Labrador Retriever', 1100, 'A Labrador Retrieverek hűségesek és barátságosak. Jó háziállatok és családi kedvencek.', 1, '2023-10-04 00:00:00'),
(3, 'Pomerániai', 1500, 'A Pomerániai kutyák aranyosak és élénkek. Kis méretük ellenére nagy személyiségűek.', 1, '2023-10-04 00:00:00'),
(4, 'Perzsa', 800, 'A Perzsa macskák csendesek és imádják a szeretetet. Szép hosszú szőrük van és kényeztetésre vágynak.', 2, '2023-10-04 00:00:00'),
(5, 'Orrnyúl', 650, 'Az orrnyúlok szórakoztatóak és kíváncsiak. Szeretnek kutakodni és játékosak.', 4, '2023-10-04 00:00:00'),
(6, 'Kanári', 200, 'A kanári madarak szépek és jókedvűek. Hangosan énekelnek és szórakoztatnak.', 5, '2023-10-04 00:00:00'),
(9, 'Sün', 100, 'A sünök cselesek és szimpatikusak. Jó kisállatok és könnyen tarthatók.', 6, '2023-10-04 00:00:00'),
(11, 'Selyem Madár', 3200, 'A selyem madarak gyönyörű tollazattal rendelkeznek. Jó társak, és énekük kellemes.', 5, '2023-10-04 00:00:00'),
(12, 'Zöld Iguána', 5000, 'A zöld iguánák exotikusak és különlegesek. A hüllők világát felfedezheted velük.', 7, '2023-10-04 00:00:00'),
(13, 'Nagyfejű Teknős', 5900, 'A nagyfejű teknősök hosszú életűek és különlegesek. Imádnivaló és hálás háziállatok.', 7, '2023-10-04 00:00:00'),
(14, 'Bengáli Papagáj', 4800, 'A bengáli papagájok intelligensek és játékosak. Hangosan és szórakoztatóan énekelnek.', 5, '2023-10-04 00:00:00'),
(15, 'Cseles Csincsilla', 3200, 'A cseles csincsillák aranyosak és puha bundájuk van. Könnyűszerrel nevelhetők és hűségesek.', 6, '2023-10-04 00:00:00'),
(18, 'Szájharmonika Cápa', 4800, 'A szájharmonika cápák félelmetesek és érdekesek. Különleges akváriumokban vagy medencékben tarthatók.', 7, '2023-10-04 00:00:00'),
(19, 'Kék Ló', 3700, 'A kék lovak különlegesek és ritkák. Méltóságteljes és különleges kísérők.', 3, '2023-10-04 00:00:00'),
(20, 'Szivárvány Papagáj', 5900, 'A szivárvány papagájok színesek és értelmesek. Hűséges társak, és szórakoztatóan énekelnek.', 5, '2023-10-04 00:00:00'),
(21, 'Szürke Tarantula', 4800, 'A szürke tarantula pókok lenyűgözőek és szemet gyönyörködtetőek. Terráriumukat ékesítik.', 7, '2023-10-04 00:00:00'),
(22, 'Cuki Borz', 2900, 'A cuki borzok aranyosak és játékosak. Jó háziállatok és kényeztetést igényelnek.', 6, '2023-10-04 00:00:00'),
(23, 'Tündéri Sárkány', 5700, 'A tündéri sárkányok különlegesek és varázslatosak. Exotikus kisállatok, amelyek gondoskodást igényelnek.', 7, '2023-10-04 00:00:00'),
(24, 'Cápa Négerkek', 4000, 'A cápa négerkek színesek és élénkek. Könnyen nevelhetők és jó szórakozást nyújtanak.', 4, '2023-10-04 00:00:00'),
(25, 'Kicsi Kutya', 1200, 'A kicsi kutyák hűségesek és játékosak. Jó családi kedvencek.', 1, '2023-10-04 00:00:00'),
(26, 'Kék Papagáj', 4800, 'A kék papagájok színesek és vidámak. Hangosan énekelnek és szórakoztatóak.', 5, '2023-10-04 00:00:00'),
(27, 'Egérke', 120, 'Az egérkék kis méretűek és aranyosak. Könnyen nevelhetők és örömöt szereznek.', 4, '2023-10-04 00:00:00'),
(28, 'Nagy Macska', 1400, 'A nagy macskák impozánsak és vadak. Egyedi kisállatok, akik exotikumot hoznak a házhoz.', 1, '2023-10-04 00:00:00'),
(30, 'Szivárvány Macska', 1100, 'A szivárvány macskák színesek és vidámak. Könnyen nevelhetők és hűségesek.', 1, '2023-10-04 00:00:00'),
(31, 'Cukiság Pók', 450, 'A cukiság pókok érdekesek és különlegesek. Terráriumukat ékesítik.', 7, '2023-10-04 00:00:00'),
(32, 'Aranyhal', 15, 'Az aranyhalak egyszerűen nevelhetők és szépek. Könnyen tarthatók akváriumokban.', 7, '2023-10-04 00:00:00'),
(33, 'Barna Papagáj', 3900, 'A barna papagájok színesek és jókedvűek. Hangosan énekelnek és jó társak.', 5, '2023-10-04 00:00:00'),
(34, 'Kígyó', 350, 'A kígyók lenyűgözőek és különlegesek. Terráriumokban tarthatók.', 7, '2023-10-04 00:00:00'),
(35, 'Nyaraló Kutya', 1300, 'A nyaraló kutyák hűségesek és játékosak. Jó választás, ha sok időt töltesz a szabadban.', 1, '2023-10-04 00:00:00'),
(36, 'Sárga Pók', 500, 'A sárga pókok különlegesek és érdekesek. Terráriumukat ékesítik.', 7, '2023-10-04 00:00:00'),
(37, 'Ezüst Macska', 1200, 'Az ezüst macskák elegánsak és vidámak. Könnyen nevelhetők és jó háziállatok.', 1, '2023-10-04 00:00:00'),
(38, 'Lila Zebra', 5500, 'A lila zebrák különlegesek és szemet gyönyörködtetőek. Kerted vagy farmod díszei lehetnek.', 3, '2023-10-04 00:00:00'),
(39, 'Kék Teknős', 3500, 'A kék teknősök színesek és különlegesek. Imádnivaló és hálás háziállatok.', 7, '2023-10-04 00:00:00'),
(40, 'Cuki Kiskutya', 1500, 'A cuki kiskutyák aranyosak és játékosak. Jó választás, ha kis lakásban élsz.', 1, '2023-10-04 00:00:00'),
(41, 'Barna Zebra', 5900, 'A barna zebrák különlegesek és szemet gyönyörködtetőek. Kerted vagy farmod díszei lehetnek.', 3, '2023-10-04 00:00:00'),
(42, 'Kék Tarantula', 5500, 'A kék tarantula pókok különlegesek és szemet gyönyörködtetőek. Terráriumukat ékesítik.', 7, '2023-10-04 00:00:00'),
(44, 'Rózsaszín Papagáj', 4800, 'A rózsaszín papagájok színesek és vidámak. Hangosan énekelnek és jó társak.', 5, '2023-10-04 00:00:00'),
(45, 'Aranyhörcsög', 350, 'Az aranyhörcsögök cselesek és aranyosak. Könnyen tarthatók.', 6, '2023-10-04 00:00:00'),
(46, 'Kék Sárkány', 4800, 'A kék sárkányok különlegesek és exotikusak. A hüllők világát felfedezheted velük.', 7, '2023-10-04 00:00:00'),
(47, 'Sárga Ló', 3700, 'A sárga lovak különlegesek és szemet gyönyörködtetőek. Kerted díszei lehetnek.', 3, '2023-10-04 00:00:00'),
(48, 'Kedves Teknős', 4500, 'A kedves teknősök aranyosak és hűségesek. Hálás háziállatok.', 6, '2023-10-04 00:00:00'),
(49, 'Színes Papagáj', 4800, 'A színes papagájok gyönyörűek és vidámak. Hangosan énekelnek és szórakoztatnak.', 5, '2023-10-04 00:00:00'),
(51, 'Szőrös Borz', 2700, 'A szőrös borzok cselesek és aranyosak. Könnyen tarthatók és vidámak.', 6, '2023-10-04 00:00:00'),
(52, 'Lila Papagáj', 4800, 'A lila papagájok színesek és jókedvűek. Hangosan énekelnek és szórakoztatnak.', 5, '2023-10-04 00:00:00'),
(53, 'Kék Zebra', 5900, 'A kék zebrák különlegesek és szemet gyönyörködtetőek. Kerted vagy farmod díszei lehetnek.', 3, '2023-10-04 00:00:00'),
(69, 'Dobermann', 1, 'Kiváló házőrzők és játékos, vidám kutyák.', 1, '2023-10-23 02:21:16'),
(70, 'Puli', 1, 'Ők az ember legállhatatosabb társai. Kiváló házőrzők és játékos, vidám kutyák.', 1, '2023-10-23 02:22:52');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `sitedetail`
--

CREATE TABLE `sitedetail` (
  `tempId` int(11) NOT NULL,
  `systemName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `contact1` bigint(21) NOT NULL,
  `contact2` bigint(21) DEFAULT NULL COMMENT 'Optional',
  `address` text NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `sitedetail`
--

INSERT INTO `sitedetail` (`tempId`, `systemName`, `email`, `contact1`, `contact2`, `address`, `dateTime`) VALUES
(1, 'Állati Otthon', '', 0, 0, '', '2021-03-23 19:56:25');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(21) NOT NULL,
  `username` varchar(21) NOT NULL,
  `firstName` varchar(21) NOT NULL,
  `lastName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `userType` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=user\r\n1=admin',
  `password` varchar(255) NOT NULL,
  `joinDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `phone`, `userType`, `password`, `joinDate`) VALUES
(1, 'admin', 'admin', 'admin', 'admin@gmail.com', 111111111, '1', '$2y$10$AAfxRFOYbl7FdN17rN3fgeiPu/xQrx6MnvRGzqjVHlGqHAM4d9T1i', '2021-04-11 11:40:58'),
(2, 'Szekix16', 'Alex', 'Szekeres', 'szekix16@gmail.com', 5362517622, '0', '$2y$10$Ysi793WTEVJeZ3ZGKrq/q.ITiYfMy2DKTsrON3PHUv.Ft5xfV/gX2', '2023-10-04 11:50:40'),
(3, 'szannab99', 'Szabó', 'Anna', 'szannab99@gmail.com', 302517622, '0', '$2y$10$4fggZoyNvtwpf60yF8TlLey8sN.dtHSnJQR4objwkInWGTX0YJmIS', '2023-10-09 00:13:00'),
(4, 'Mekk', 'Mekk', 'Elek', 'mekkelek@gamil.com', 6304170374, '0', '$2y$10$3uvuMAkbHJUm/7eKz6nxyerx0Hrp.4tTpLqisGqiq1r25p.LLtWJy', '2023-10-09 00:15:29');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `viewcart`
--

CREATE TABLE `viewcart` (
  `cartItemId` int(11) NOT NULL,
  `pizzaId` int(11) NOT NULL,
  `itemQuantity` int(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `addedDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `viewcart`
--

INSERT INTO `viewcart` (`cartItemId`, `pizzaId`, `itemQuantity`, `userId`, `addedDate`) VALUES
(14, 45, 1, 2, '2023-10-18 00:32:48'),
(15, 21, 1, 2, '2023-10-18 00:33:31'),
(16, 48, 1, 2, '2023-10-18 00:38:55');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categorieId`);
ALTER TABLE `categories` ADD FULLTEXT KEY `categorieName` (`categorieName`,`categorieDesc`);

--
-- A tábla indexei `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contactId`);

--
-- A tábla indexei `contactreply`
--
ALTER TABLE `contactreply`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `deliverydetails`
--
ALTER TABLE `deliverydetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orderId` (`orderId`);

--
-- A tábla indexei `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- A tábla indexei `pizza`
--
ALTER TABLE `pizza`
  ADD PRIMARY KEY (`pizzaId`);
ALTER TABLE `pizza` ADD FULLTEXT KEY `pizzaName` (`pizzaName`,`pizzaDesc`);

--
-- A tábla indexei `sitedetail`
--
ALTER TABLE `sitedetail`
  ADD PRIMARY KEY (`tempId`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`);

--
-- A tábla indexei `viewcart`
--
ALTER TABLE `viewcart`
  ADD PRIMARY KEY (`cartItemId`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `categories`
--
ALTER TABLE `categories`
  MODIFY `categorieId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT a táblához `contact`
--
ALTER TABLE `contact`
  MODIFY `contactId` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `contactreply`
--
ALTER TABLE `contactreply`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `deliverydetails`
--
ALTER TABLE `deliverydetails`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `pizza`
--
ALTER TABLE `pizza`
  MODIFY `pizzaId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT a táblához `sitedetail`
--
ALTER TABLE `sitedetail`
  MODIFY `tempId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `viewcart`
--
ALTER TABLE `viewcart`
  MODIFY `cartItemId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
