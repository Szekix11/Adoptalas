<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Szekeres Alex Patrik, Merza Nikolett Éva, Takács Lilla">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Pizza rendelés">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <head>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    
    <title>Kapcsolatok</title>
    <link rel = "icon" href ="img/logo.jpg" type = "image/x-icon">
    <style>
        .contact2 {
            font-family: "Montserrat", sans-serif;
            color: black;
            font-weight: 100;
            background-color: DimGray;
            background-size: cover;
            background-position: center center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .contact-box {
            background-color: Gainsboro;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(, 0, 0, 0.2);
            text-align: center;
        }

        .contact-box h5 {
            font-weight: 600;
        }

        .contact-box p {
            font-size: 18px;
            margin-bottom: 20px;
        }

        .gmail-icon {
            font-size: 24px;
            margin-left: 5px;
        }
    </style>

</head>
<body>
<?php include 'partials/_dbconnect.php';?>
<?php include 'partials/_nav.php';?>

<div class="contact2">
    <div class="container">
        <div class="row contact-container">
            <div class="col-lg-8 mx-auto">
                <div class="contact-box">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <h2 class="title">Kapcsolatok</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Telefonszám:</h5>
                            <p><a href="tel:+36702517822">+36 70 251 7822</a></p>
                        </div>
                        <div class="col-md-6">
                        
                    <h5>Cím:</h5>
                    <p><a href="https://www.google.com/maps/search/?api=1&query=6723+Szeged+Kárász+utca+7" target="_blank">6723 Szeged Kárász utca 7.</a></p>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>E-mail cím:</h5>
                            <p>
                                <a href="mailto:pizzamania@ugyfelszolgalat.hu">
                                   </i> pizzamania@ugyfelszolgalat.hu
                                    <i class="fas fa-envelope gmail-icon"  onclick="location.href='mailto:pizza@example.com'"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'partials/_footer.php';?> 
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         

</body>
</html>





