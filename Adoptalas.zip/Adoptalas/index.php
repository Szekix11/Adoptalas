<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Pizza rendelés">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Kezdőoldal</title>
    <link rel="icon" href="img/logo.jpg" type="image/x-icon">
    <style>
        /* Dizájn módosítások az üdvözlő ablakhoz */
        #welcome-popup {
            background: rgba(0, 0, 0, 0.5); /* Átlátszóság beállítása */
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: #007BFF;
            color: white;
            border: 1px solid white;
            border-radius: 10px; /* Kerekítés a sarkokon */
        }

        .modal-title {
            color: white;
        }

        /* Stílus a bezárás gombhoz */
        .close {
            color: white;
            font-size: 24px;
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer; /* Hozzáadva, hogy az ikonra kattintva is zárható legyen */
        }

        /* Stílus a "Tovább a weboldalra" gombhoz */
        #continue-button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php include 'partials/_dbconnect.php';?>
    <?php require 'partials/_nav.php' ?>

    <!-- Category container starts here -->
    <div class="container my-3 mb-5">
        <div class="col-lg-2 text-center bg-light my-3" style="margin:auto;border-top: 2px groove black;border-bottom: 2px groove black;">     
            <h2 class="text-center">Állataink</h2>
        </div>
        <div class="row">
            <!-- Fetch all the categories and use a loop to iterate through categories -->
            <?php 
                $sql = "SELECT * FROM `categories`"; 
                $result = mysqli_query($conn, $sql);
                while($row = mysqli_fetch_assoc($result)){
                    $id = $row['categorieId'];
                    $cat = $row['categorieName'];
                    $desc = $row['categorieDesc'];
                    echo '<div class="col-xs-3 col-sm-3 col-md-3">
                            <div class="card" style="width: 18rem;">
                                <img src="img/card-'.$id. '.jpg" class="card-img-top" alt="image for this category" width="249px" height="270px">
                                <div class="card-body">
                                    <h5 class="card-title"><a href="viewPizzaList.php?catid=' . $id . '">' . $cat . '</a></h5>
                                    <p class="card-text">' . substr($desc, 0, 30). '... </p>
                                    <a href="viewPizzaList.php?catid=' . $id . '" class="btn btn-primary">Mutasd mind</a>
                                </div>
                            </div>
                        </div>';
                }
            ?>
        </div>
    </div>

    <?php require 'partials/_footer.php' ?>

    <div id="welcome-popup" class="modal" style="margin: 1cm;">
    <div class="modal-dialog modal-dialog-centered modal-lg" style="max-width: 800px; max-height: 600px;">
        <div class="modal-content" style="background: #333; color: white;">
   

            <div class="modal-body" style="max-height: 400px; overflow-y: auto; text-align: center;">
                <h2>Üdvözöljük az Állat Örökbe Fogadás Oldalunkon!</h2>
                <p>Ez az oldal arra szolgál, hogy segítsünk a kisállatoknak új otthonra találni. A célunk az, hogy minden kisállat boldog és gondoskodó családban élhessen.</p>
                <h4>Miért minket válasszon?</h4>
                <p>A mi oldalunkon számos kisállat található, akik várják, hogy örökbefogadásra kerüljenek. Az állatok egészségesek, gondozottak és készen állnak az új életre.</p>
                <h4>Hogyan működik?</h4>
                <p>Az oldalon könnyen böngészheti az elérhető kisállatokat kategóriák szerint. Ha megtalálta a tökéletes társat, lépjen kapcsolatba az örökbeadóval, és kezdje meg az örökbefogadási folyamatot.</p>
                <button id="continue-button" style="background-color: #007BFF; color: white; border: none; padding: 10px 20px; margin-top: 20px; border-radius: 5px; cursor: pointer;">Tovább a weboldalra</button>
            </div>
        </div>
    </div>
</div>



    <!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script>
    $(document).ready(function () {
        // Üdvözlő ablak megjelenítése
        $("#welcome-popup").modal('show');

        // Az X gombra kurzorral való ráhúzás és eltávolítás
$(".close")
    .hover(function () {
        $(this).css("background-color", "gray");
        $(this).css("border-radius", "50%");
    }, function () {
        $(this).css("background-color", "red");
    })
    .click(function () {
        $("#welcome-popup").modal('hide');
    });

        // A "Tovább a weboldalra" gombra kurzorral való ráhúzás és eltávolítás
        $("#continue-button")
            .hover(function () {
                $(this).css("background-color", "green");
            }, function () {
                $(this).css("background-color", "#007BFF"); // Alapértelmezett kék háttér
            })
            .click(function () {
                $("#welcome-popup").modal('hide');
            });


        // Esc billentyűvel is lehessen becsukni az ablakot
        $(document).keydown(function (event) {
            if (event.which == 27) { // 27 a billentyűkódja az Esc gombnak
                $("#welcome-popup").modal('hide');
            }
        });
    });
</script>






    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>