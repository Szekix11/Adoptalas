<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Szekeres Alex Patrik, Merza Nikolett Éva, Takács Lilla">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="animals rendelés">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <head>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    
    <title>Kapcsolatok</title>
    <link rel = "icon" href ="img/logo.jpg" type = "image/x-icon">

</head>
<body>
<?php include 'partials/_dbconnect.php';?>
<?php include 'partials/_nav.php';?>


  <style>
  .footer {
      position: fixed;
      bottom: 0;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #3498db;
      color: #fff;
      text-align: center;
      padding: 20px 0;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }

    .rating-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    .rating {
      display: flex;
      justify-content: center;
      gap: 10px;
    }

    .like-button, .unlike-button {
      background-color: #3498db;
      color: #fff;
      border: none;
      border-radius: 5px;
      padding: 10px;
      cursor: pointer;
    }

    .like-button:hover, .unlike-button:hover {
      background-color: #1976D2;
    }

    .rating-content {
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  align-items: center;
}

.comments-section {
  margin-top: 20px;
  text-align: center;
}

    label {
      font-weight: bold;
    }

    textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      background-color: #3498db;
      color: #fff;
      border: none;
      border-radius: 5px;
      padding: 10px 20px;
      cursor: pointer;
    }

    button:hover {
      background-color: #1976D2;
    }

    .comment-container {
      margin-top: 20px;
    }

    .comment {
      background-color: #f9f9f9;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-bottom: 10px;
    }

    .comment-bubble {
      background-color: #3498db;
      color: #fff;
      padding: 10px;
      border-radius: 5px;
      border: 1px solid #1976D2;
      position: relative;
    }

    .comment-bubble::before {
      content: '';
      position: absolute;
      top: 50%;
      right: 100%;
      border-width: 10px;
      border-style: solid;
      border-color: transparent transparent transparent #3498db;
    }

    .container {
  display: flex;
  justify-content: center; /* Vízszintes középre igazítás */
  align-items: center; /* Függőleges középre igazítás */
  height: 100vh; /* A teljes viewport magasságig terjedjen a tartalom */
}

.row {
  max-width: 800px;
  width: 100%;
  padding: 20px;
}

.rating-content {
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  text-align: center; /* Tartalom középre igazítása */
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px; /* Elemek közötti távolság */
}

.rating {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 20px; /* Az értékelés szekció eltolása lejjebb */
}

.comments-section {
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
}
  </style>
</head>
<body>

  <div class="container">
    <section class="row">
      <div class="col-lg-6 pt-4 pt-lg-0 content">
        <div class="rating-content">
          <h2>Értékelés</h2>
          <div class="rating">
            <button class="like-button" onclick="likeProduct()">Like</button>
            <button class="unlike-button" onclick="unlikeProduct()">Unlike</button>
          </div>
          <p><b>Értékelés százalékban: <span id="ratingPercentage">0%</span></b></p>
        </div>
        <div class="comments-section">
          <h2>Hozzászólások</h2>
          <label for="comment">Hozzászólás:</label>
          <textarea id="comment" rows="4" cols="50"></textarea>
          <button onclick="addComment()">Hozzászólás hozzáadása</button>
          <div id="comments" class="comment-container"></div>
        </div>
      </div>
    </section>
  </div>

  <script>
    let currentLikes = 0;
    let currentDislikes = 0;

    function likeProduct() {
      currentLikes++;
      updateRatingPercentage();
    }

    function unlikeProduct() {
      currentDislikes++;
      updateRatingPercentage();
    }

    function addComment() {
      const commentText = document.getElementById("comment").value;
      const commentsContainer = document.getElementById("comments");

      if (commentText.trim() !== "") {
        const commentElement = document.createElement("div");
        commentElement.classList.add("comment");
        commentElement.innerHTML = `<div class="comment-bubble">${commentText}</div>`;
        commentsContainer.appendChild(commentElement);
        document.getElementById("comment").value = ""; // Töröljük a beviteli mezőt
      }
    }

    function updateRatingPercentage() {
      const totalVotes = currentLikes + currentDislikes;
      if (totalVotes === 0) {
        document.getElementById("ratingPercentage").textContent = "Nincs értékelés még.";
      } else {
        const percentage = (currentLikes / totalVotes) * 100;
        document.getElementById("ratingPercentage").textContent = percentage.toFixed(2) + "% pozitív értékelés.";
      }
    }
  </script>
</body>
</html>


<?php include 'partials/_footer.php';?> 
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         

</body>
</html>





