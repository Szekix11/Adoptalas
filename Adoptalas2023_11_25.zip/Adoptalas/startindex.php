<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Szekeres Alex Patrik, Merza Nikolett Éva, Takács Lilla">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Örökbefogadás">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

    <title>Rólunk</title>
    <link rel = "icon" href ="img/logo.jpg" type = "image/x-icon">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
  <head>
  <style>
    .carousel-background {
    background-image: url('img/slide.jpg');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    width: 100%;
    height: 100vh;
}

  </style>
   

  </head>
  <body>
    
  <?php include 'partials/_dbconnect.php';?>
  <?php include 'partials/_nav.php';?>
  
      <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">
        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>
        
          <!-- Slide 1 -->
          <div class="carousel-item active">
            <div class="carousel-background"></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Üdvözöllek a <span>Állati Otthon oldalán</span></h2>
                <div class="text-bg">
        <p class="animate__animated animate__fadeInUp" style="font-size: 24px; color: #fff; text-shadow: 2px 2px 4px #333;">Örömmel üdvözöljük Önt az Állati Otthon oldalán! Nálunk lehetősége van új családtagot találni és egy örökbefogadott kisállat boldogságát megteremteni.</p>
        <p class="animate__animated animate__fadeInUp" style="font-size: 24px; color: #fff; text-shadow: 2px 2px 4px #333;">Az örökbefogadás a legjobb ajándék, amit adhatsz egy kisállatnak, és cserébe ők is örökre hálásak lesznek.</p>
        <p class="animate__animated animate__fadeInUp" style="font-size: 24px; color: #fff; text-shadow: 2px 2px 4px #333;">Böngésszen kínálatunkban, és találja meg azt a kisállatot, amely megdobogtatja a szívét!</p>
      
     
</div>           
       <a href="index.php" class="btn-get-started animate__animated animate__fadeInUp scrollto">Kezd el az örökbefogadást</a>
                

                <a href="about.php" class="btn-get-started animate__animated animate__fadeInUp scrollto">Rólunk</a>
              </div>
            </div>
          </div>
          

       

       

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

  

    <!-- ======= About Us Section ======= -->


  </main>

  <?php include 'partials/_footer.php';?> 

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/jquery-sticky/jquery.sticky.js"></script>
    <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counterup/counterup.min.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>


  </body>
</html>
