<div class="container-fluid" style="margin-top:98px">
	
	<div class="col-lg-12">
		<div class="row">
			<!-- FORM Panel -->
			<div class="col-md-4">
			<form action="partials/_menuManage.php" method="post" enctype="multipart/form-data">
				<div class="card mb-3">
					<div class="card-header" style="background-color: rgb(111 202 203);">
						Új tétel készítés
				  	</div>
					<div class="card-body">
							<div class="form-group">
								<label class="control-label">Fajta: </label>
								<input type="text" class="form-control" name="name" required>
							</div>
							<div class="form-group">
								<label class="control-label">Név: </label>
								<input type="text" class="form-control" name="animalsNickname" required>
							</div>
							<div class="form-group">
								<label class="control-label">Leírás: </label>
								<textarea cols="30" rows="3" class="form-control" name="description" required></textarea>
							</div>
                            <div class="form-group">
								<label class="control-label">Ár:</label>
								<input type="number" class="form-control" name="price" required min="1">
							</div>	
							<div class="form-group">
								<label class="control-label">Kategória: </label>
								<select name="categoryId" id="categoryId" class="custom-select browser-default" required>
								<option hidden disabled selected value>Üres</option>
                                <?php
                                    $catsql = "SELECT * FROM `categories`"; 
                                    $catresult = mysqli_query($conn, $catsql);
                                    while($row = mysqli_fetch_assoc($catresult)){
                                        $catId = $row['categorieId'];
                                        $catName = $row['categorieName'];
                                        echo '<option value="' .$catId. '">' .$catName. '</option>';
                                    }
                                ?>
								</select>
							</div>
							
							<div class="form-group">
								<label for="image" class="control-label">Kép</label>
								<input type="file" name="image" id="image" accept=".jpg" class="form-control" required style="border:none;">
								
							</div>
					</div>
							
					<div class="card-footer">
						<div class="row">
							<div class="mx-auto">
								<button type="submit" name="createItem" class="btn btn-sm btn-primary">Létrehozás </button>
							</div>
						</div>
					</div>
				</div>
			</form>
			</div>
			<!-- FORM Panel -->

			<!-- Table Panel -->
			<div class="col-md-8">
				<div class="card">
					<div class="card-body">
						<table class="table table-bordered table-hover mb-0">
							<thead style="background-color: rgb(111 202 203);">
								<tr>
									<th class="text-center" style="width:7%;">Termék Id</th>
									<th class="text-center">Kép</th>
									<th class="text-center" style="width:58%;">Leírás</th>
									<th class="text-center" style="width:18%;">Szerkesztés</th>
								</tr>
							</thead>
							<tbody>
							<?php
    $sql = "SELECT * FROM `animals`";
    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_assoc($result)){
        $animalsId = $row['animalsId'];
        $animalsName = $row['animalsName'];
        $animalsPrice = $row['animalsPrice'];
        $animalsDesc = $row['animalsDesc'];
        $animalsCategorieId = $row['animalsCategorieId'];
        $animalsNickname = $row['animalsNickname']; // Corrected this line

        echo '<tr>
                <td class="text-center">' .$animalsCategorieId. '</td>
                <td>
                    <img src="/Adoptalas/img/animals-'.$animalsId. '.jpg" alt="image for this item" width="150px" height="150px">
                </td>
                <td>
                    <p>Name : <b>' .$animalsName. '</b></p>
                    <p>Nickname : <b>' .$animalsNickname. '</b></p>
                    <p>Description : <b class="truncate">' .$animalsDesc. '</b></p>
                    <p>Price : <b>' .$animalsPrice. '</b></p>
                </td>
                <td class="text-center">
                    <div class="row mx-auto" style="width:112px">
                        <button class="btn btn-sm btn-primary" type="button" data-toggle="modal" data-target="#updateItem' .$animalsId. '">Szerkesztés</button>
                        <form action="partials/_menuManage.php" method="POST">
                            <button name="removeItem" class="btn btn-sm btn-danger" style="margin-left:9px;">Törlés</button>
                            <input type="hidden" name="animalsId" value="'.$animalsId. '">
                        </form>
                    </div>
                </td>
            </tr>';
    }
?>

							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	
</div>

<?php 
    $animalssql = "SELECT * FROM `animals`";
    $animalsResult = mysqli_query($conn, $animalssql);
    while($animalsRow = mysqli_fetch_assoc($animalsResult)){
        $animalsId = $animalsRow['animalsId'];
        $animalsName = $animalsRow['animalsName'];
        $animalsPrice = $animalsRow['animalsPrice'];
        $animalsCategorieId = $animalsRow['animalsCategorieId'];
		$animalsNickname = $animalsRow['animalsNickname'];
        $animalsDesc = $animalsRow['animalsDesc'];
?>

<!-- Modal -->
<div class="modal fade" id="updateItem<?php echo $animalsId; ?>" tabindex="-1" role="dialog" aria-labelledby="updateItem<?php echo $animalsId; ?>" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: rgb(111 202 203);">
        <h5 class="modal-title" id="updateItem<?php echo $animalsId; ?>">Tétel Id <?php echo $animalsId; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  	<form action="partials/_menuManage.php" method="post" enctype="multipart/form-data">
		    <div class="text-left my-2 row" style="border-bottom: 2px solid #dee2e6;">
		   		<div class="form-group col-md-8">
					<b><label for="image">Kép</label></b>
					<input type="file" name="itemimage" id="itemimage" accept=".jpg" class="form-control" required style="border:none;" onchange="document.getElementById('itemPhoto').src = window.URL.createObjectURL(this.files[0])">
					
					<input type="hidden" id="animalsId" name="animalsId" value="<?php echo $animalsId; ?>">
					<button type="submit" class="btn btn-success my-1" name="updateItemPhoto">Kép csere</button>
				</div>
				<div class="form-group col-md-4">
					<img src="/Adoptalas/img/animals-<?php echo $animalsId; ?>.jpg" id="itemPhoto" name="itemPhoto" alt="item image" width="100" height="100">
				</div>
			</div>
		</form>
		<form action="partials/_menuManage.php" method="post">
            <div class="text-left my-2">
                <b><label for="name">Név</label></b>
                <input class="form-control" id="name" name="name" value="<?php echo $animalsName; ?>" type="text" required>
            </div>
			<div class="text-left my-2 row">
				<div class="form-group col-md-6">
                	<b><label for="price">Ár</label></b>
                	<input class="form-control" id="price" name="price" value="<?php echo $animalsPrice; ?>" type="number" min="1" required>
				</div>
				<div class="form-group col-md-6">
					<b><label for="catId">Kategória Id</label></b>
                	<input class="form-control" id="catId" name="catId" value="<?php echo $animalsCategorieId; ?>" type="number" min="1" required>
				</div>
				<div class="form-group col-md-6">
					<b><label for="animalsNickname">Becenév:</label></b>
                	<input class="form-control" id="animalsNickname" name="animalsNickname" value="<?php echo $animalsNickname; ?>" type="text"  required>
				</div>
            </div>
            <div class="text-left my-2">
                <b><label for="desc">Leírás</label></b>
                <textarea class="form-control" id="desc" name="desc" rows="2" required minlength="6"><?php echo $animalsDesc; ?></textarea>
            </div>
            <input type="hidden" id="animalsId" name="animalsId" value="<?php echo $animalsId; ?>">
            <button type="submit" class="btn btn-success" name="updateItem">Frissítés</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php
	}
?>