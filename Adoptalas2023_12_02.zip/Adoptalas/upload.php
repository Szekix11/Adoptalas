<?php
include '_dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadDir = "uploads/";
    $allowedExtensions = array("pdf", "doc", "docx");

    // Fájlfeltöltéshez szükséges adatok
    $fileName = $_FILES['file']['name'];
    $fileSize = $_FILES['file']['size'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileType = $_FILES['file']['type'];

    // Egyéb űrlapadatok
    $address = $_POST['address'];
    $address1 = $_POST['address1'];
    $phone = $_POST['phone'];
    $zipcode = $_POST['zipcode'];
    $password = $_POST['password'];
    $amount = $_POST['amount'];

    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (in_array($fileExtension, $allowedExtensions) && $fileSize < 2097152) { // 2 MB méretkorlát

        $uploadPath = $uploadDir . basename($fileName);
        move_uploaded_file($fileTmpName, $uploadPath);

        $sql = "INSERT INTO uploaded_files (file_name, file_path, address, address1, phone, zipcode, password, amount) 
                VALUES ('$fileName', '$uploadPath', '$address', '$address1', '$phone', '$zipcode', '$password', '$amount')";

        $result = mysqli_query($conn, $sql);

        if ($result) {
            echo "A fájl sikeresen feltöltve és az adatbázisba mentve.";
        } else {
            echo "Hiba az adatbázisba mentés során: " . mysqli_error($conn);
        }

    } else {
        echo "Hiba: Érvénytelen fájltípus vagy túl nagy fájlméret.";
    }
}
?>
