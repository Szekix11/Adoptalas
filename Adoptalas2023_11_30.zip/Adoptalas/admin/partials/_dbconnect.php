<?php
$server = "localhost"; // Adatbázis szerver neve
$username = "root";  // Adatbázis felhasználónév
$password = "";  // Adatbázis jelszó
$database = "OPD";  // Adatbázis neve

$conn = mysqli_connect($server, $username, $password, $database); // Adatbázis kapcsolat létrehozása

// Ellenőrzi, hogy sikeresen létrejött-e a kapcsolat
if (!$conn){
    die("Error". mysqli_connect_error());
}

?>
