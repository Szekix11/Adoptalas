<?php
/*session_start();: Ez a sor elindítja vagy folytatja a munkamenetet a felhasználóval. A munkamenet az adatok tárolására és megosztására szolgál a különböző oldalak között.

unset($_SESSION["adminloggedin"]), unset($_SESSION["adminusername"]), unset($_SESSION["adminuserId"]): Ezek a sorok eltávolítják a munkamenet változókat, amelyek az adminisztrátor 
felhasználó bejelentkezési állapotát, felhasználónevet és azonosítót tartalmazzák. Ezzel a felhasználó kijelentkezik, mivel ezek a változók törlésre kerülnek a munkamenetből.

header('Location: ' . $_SERVER['HTTP_REFERER']);: Ez a sor átirányítja a felhasználót az előző oldalra, ahonnan a kijelentkezési műveletet indították. Az $_SERVER['HTTP_REFERER'] 
változó tartalmazza az előző oldal URL-jét.* */
session_start();
echo "Kérlek várj";
unset($_SESSION["adminloggedin"]);
unset($_SESSION["adminusername"]);
unset($_SESSION["adminuserId"]);



header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
