<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Szekeres Alex Patrik, Merza Nikoletta Éva, Takács Lilia">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Örökbefogadás">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Keresés</title>
    <link rel="icon" href="img/logo.jpg" type="image/x-icon">
    <style>
        #cont {
            min-height: 515px;
        }
    </style>
</head>
<body>
    <?php include 'partials/_dbconnect.php'; ?>
    <?php require 'partials/_nav.php'; ?>

    <div class="container my-3">
        <h2 class="py-2">Keresési találatok <em>"<?php echo $_GET['search']?>"</em> :</h2>
        <h3><span id="cat" class="py-2"></span></h3>
        <div class="row">
        <?php 
            $noResult = true;
            $searchTerm = mysqli_real_escape_string($conn, $_GET['search']);
            $sqlCategories = "SELECT * FROM `categories` WHERE MATCH(categorieName, categorieDesc) AGAINST('$searchTerm' IN NATURAL LANGUAGE MODE)";
            $resultCategories = mysqli_query($conn, $sqlCategories);
            while($row = mysqli_fetch_assoc($resultCategories)){
                ?><script> document.getElementById("cat").innerHTML = "Kategóriák ";</script> <?php 
                $noResult = false;
                $catId = $row['categorieId'];
                $catname = $row['categorieName'];
                $catdesc = $row['categorieDesc'];
                
                echo '<div class="col-xs-3 col-sm-3 col-md-3">
                    <div class="card" style="width: 18rem;">
                        <img src="img/card-'.$catId. '.jpg" class="card-img-top" alt="image for this animals" width="249px" height="270px">
                        <div class="card-body">
                            <h5 class="card-title"><a href="viewanimalsList.php?catid=' . $catId . '">' . $catname . '</a></h5>
                            <p class="card-text">' . substr($catdesc, 0, 29). '...</p>
                            <a href="viewanimalsList.php?catid=' . $catId . '" class="btn btn-primary">Mindet mutasd</a>
                        </div>
                    </div>
                </div>';
            }
        ?>
        </div>
    </div>

    <div class="container my-3" id="cont">
        <h3><span id="iteam" class="py-2"></span></h3>
        <div class="row">
        <?php 
            $sqlAnimals = "SELECT * FROM `animals` WHERE MATCH(animalsName, animalsDesc) AGAINST('$searchTerm' IN NATURAL LANGUAGE MODE)"; 
            $resultAnimals = mysqli_query($conn, $sqlAnimals);
            while($row = mysqli_fetch_assoc($resultAnimals)){
                ?><script> document.getElementById("iteam").innerHTML = "Találatok: ";</script> <?php
                $noResult = false;
                $animalsId = $row['animalsId'];
                $animalsName = $row['animalsName'];
                $animalsDesc = $row['animalsDesc'];
                $animalsCategorieId = $row['animalsCategorieId'];
                
                echo '<div class="col-xs-3 col-sm-3 col-md-3">
                    <div class="card" style="width: 18rem;">
                        <img src="img/animals-'.$animalsId. '.jpg" class="card-img-top" alt="image for this animals" width="249px" height="270px">
                        <div class="card-body">
                            <h5 class="card-title">' . substr($animalsName, 0, 20). '...</h5>
                            <p class="card-text">' . substr($animalsDesc, 0, 29). '...</p>
                            <div class="row justify-content-center">';
                                if($loggedin){
                                    $quaSql = "SELECT `itemQuantity` FROM `viewcart` WHERE animalsId = '$animalsId' AND `userId`='$userId'";
                                    $quaresult = mysqli_query($conn, $quaSql);
                                    $quaExistRows = mysqli_num_rows($quaresult);
                                    if($quaExistRows == 0) {
                                        echo '<form action="partials/_manageCart.php" method="POST">
                                              <input type="hidden" name="itemId" value="'.$animalsId. '">
                                              <button type="submit" name="addToCart" class="btn btn-primary mx-2">Örökbefogadás</button>';
                                    }else {
                                        echo '<a><button class="btn btn-primary mx-2">Kiválasztva</button></a>';
                                    }
                                }
                                else{
                                    echo '<button class="btn btn-primary mx-2" data-toggle="modal" data-target="#loginModal">Kosárhoz adás</button>';
                                }
                                echo '</form>
                                <a href="viewanimals.php?animalsid=' . $animalsId . '"><button class="btn btn-primary">Megtekint</button></a>
                            </div>
                        </div>
                    </div>
                </div>';
            }
            if($noResult) {
                echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1>Keresési szó: - <em>"' .$_GET['search']. '"</em> - Nincs találat!.</h1>
                        <p class="lead"> Javaslat: <ul>
                            <li>Próbálkozz kulcs szavakkal.</li></ul>
                        </p>
                    </div>
                </div> ';
            }
        ?>
        </div>
    </div>

    <?php require 'partials/_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>
