<div class="footer container-fluid bg-dark text-light" style="position: fixed; bottom: 0; left: 0; right: 0; pointer-events: none; z-index: 999;">
    <p class="text-center py-2 mb-0">SZTE JGYPK Szerveroldali programozás 2023 </p>
</div>
