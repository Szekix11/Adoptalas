-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Dec 06. 15:22
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `hazi7`
--
CREATE DATABASE IF NOT EXISTS `hazi7` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hazi7`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `menuk`
--

CREATE TABLE `menuk` (
  `menu_nev` varchar(20) NOT NULL,
  `menu_nyelv` varchar(20) NOT NULL,
  `menu_link` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `menuk`
--

INSERT INTO `menuk` (`menu_nev`, `menu_nyelv`, `menu_link`) VALUES
('Home', 'angol', 'home.php'),
('About', 'angol', 'about.php'),
('Contact', 'angol', 'contact.php'),
('Fooldal', 'magyar', 'home.php'),
('Rolunk', 'magyar', 'about.php'),
('Elerhetoseg', 'magyar', 'contact.php');
--
-- Adatbázis: `opd`
--
CREATE DATABASE IF NOT EXISTS `opd` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `opd`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `animals`
--

CREATE TABLE `animals` (
  `animalsId` int(12) NOT NULL,
  `animalsName` varchar(255) NOT NULL,
  `animalsNickname` varchar(255) DEFAULT NULL,
  `animalsPrice` int(12) NOT NULL,
  `animalsDesc` text NOT NULL,
  `animalsCategorieId` int(12) NOT NULL,
  `animalsPubDate` datetime NOT NULL DEFAULT current_timestamp(),
  `animalsAge` int(11) DEFAULT NULL,
  `animalsGender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `animals`
--

INSERT INTO `animals` (`animalsId`, `animalsName`, `animalsNickname`, `animalsPrice`, `animalsDesc`, `animalsCategorieId`, `animalsPubDate`, `animalsAge`, `animalsGender`) VALUES
(1, 'Keverék', 'Vackor', 1200, 'Státusz:Gazdit keres\r\nElvihető (előreláthatóan):2017. május 5. után bármikor\r\nKora:7 éves\r\nIvar:hím', 1, '2023-10-04 00:00:00', 7, 'hím'),
(2, 'Labrador Retriever', 'Buddy', 1100, 'A Labrador Retrieverek hűségesek és barátságosak. Jó háziállatok és családi kedvencek.', 1, '2023-10-04 00:00:00', 4, 'hím'),
(3, 'Pomerániai', 'Pommy', 1500, 'A Pomerániai kutyák aranyosak és élénkek. Kis méretük ellenére nagy személyiségűek.', 1, '2023-10-04 00:00:00', 3, 'hím'),
(4, 'Perzsa', 'Fluffy', 800, 'A Perzsa macskák csendesek és imádják a szeretetet. Szép hosszú szőrük van és kényeztetésmre vágynak.', 2, '2023-10-04 00:00:00', 5, 'hím'),
(5, 'Orrnyúl', 'Bugsy', 650, 'A magyar óriás nyúlak szórakoztatóak és kíváncsiak. Szeretnek kutakodni és játékosak.', 4, '2023-10-04 00:00:00', 2, 'hím'),
(6, 'hímári', 'Sunny', 200, 'A hímári madarak szépek és jókedvűek. Hangosan énekelnek és szórakoztatnak.', 5, '2023-10-04 00:00:00', 3, 'hím'),
(15, 'Cseles Csincsilla', 'Chilly', 3200, 'A cseles csincsillák aranyosak és puha bundájuk van. Könnyűszerrel nevelhetők és hűségesek.', 6, '2023-10-04 00:00:00', 1, 'nőstény'),
(33, 'Barna Papagáj', 'Browny', 3900, 'A barna papagájok színesek és jókedvűek. Hangosan énekelnek és jó társak.', 5, '2023-10-04 00:00:00', 4, 'nőstény'),
(40, 'Tacsi', 'Wiener', 1500, 'A tacsi kiskutyák aranyosak és játékosak. Jó választás, ha kis lakásban élsz.', 1, '2023-10-04 00:00:00', 1, 'hím'),
(45, 'Tengerimalac', 'Whiskers', 350, 'A tengerimalacok cselesek és aranyosak. Könnyen tarthatók.', 6, '2023-10-04 00:00:00', 2, 'nőstény'),
(52, 'Lila Papagáj', 'Purpley', 4800, 'A lila papagájok színesek és jókedvűek. Hangosan énekelnek és szórakoztatnak.', 5, '2023-10-04 00:00:00', 3, 'nőstény'),
(69, 'Dobermann', 'Doby', 1, 'Kiváló házőrzők és játékos, vidám kutyák.', 1, '2023-10-23 02:21:16', 4, 'nőstény'),
(70, 'Puli', 'Puffy', 1, 'Ők az ember legállhatatosabb társai. Kiváló házőrzők és játékos, vidám kutyák.', 1, '2023-10-23 02:22:52', 4, 'nőstény'),
(71, 'Magyar Vizsla', 'Vizzy', 2, 'Barátságos gazdi szerető kutyák.', 1, '2023-10-23 23:51:38', 4, 'nőstény'),
(72, 'husky', 'Tappancs', 1, 'Barátságos,jó nevelt kutya.', 1, '2023-10-23 23:57:01', 3, 'nőstény'),
(73, 'Bengáli macska', 'Benny Jr.', 1, 'Barátságos fiatal kis cica.', 2, '2023-10-23 23:59:16', 3, 'nőstény'),
(74, 'Tacskómacska', 'Wiener Jr.', 1, 'Barátságos, jó nevelt cica.', 2, '2023-10-24 00:00:30', 3, 'nőstény'),
(75, 'Alpaka', 'Fluffy Jr.', 1, 'Alpakánk barátságos szertő gazdira vágyik.', 8, '2023-10-24 00:05:34', 2, 'nőstény');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `categories`
--

CREATE TABLE `categories` (
  `categorieId` int(12) NOT NULL,
  `categorieName` varchar(255) NOT NULL,
  `categorieDesc` text NOT NULL,
  `categorieCreateDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `categories`
--

INSERT INTO `categories` (`categorieId`, `categorieName`, `categorieDesc`, `categorieCreateDate`) VALUES
(1, 'Kutyáink', 'A legjobb barátok. A kutya az ember leghűségesebb társa. Kedvenc négylábú kutyáink különböző méretűek és fajtájúak, de mindegyikük imádnivaló és várja, hogy egy szerető otthonba kerüljön.', '2023-10-04 00:00:00'),
(2, 'Macskáink', 'Különböző macska fajták várják, hogy otthonra találjanak. Legyen szőrös barátja, és élvezze a macskák társaságát. Mindegyik macska egyedi személyiséggel rendelkezik, és hűséges társa lehet.', '2023-10-04 00:00:00'),
(4, 'Nyúlak', 'A nyulak csendes és bájos háziállatok. Sokféle nyúlfajta közül választhat, és mindegyikük hűséges társ lehet. A nyúlok ápolása és etetése egyszerű, és örömüket leli a játékban.', '2023-10-04 00:00:00'),
(5, 'Madarak', 'A madarak csodálatos és színes lények. Legyen szárnyas barátja, és hallgassa meg éneküket minden nap. A különböző madárfajták szépségükkel és egyediségükkel elvarázsolják majd önt.', '2023-10-04 00:00:00'),
(6, 'Kisemlőseink', 'Az apró kisemlősök különleges örömet hoznak az otthonába. Például hörcsögök, patkányok és csincsillák szép, kis háziállatok lehetnek. Találja meg a tökéletes kisemlőst, hogy elkényeztesse őket.', '2023-10-04 00:00:00'),
(8, 'Egyebek', 'Nem csak a hagyományos háziállatok érnek, sok más különleges és szokatlan állat is várja, hogy örökbefogadják őket. Fedezze fel a különleges állatok világát, és találja meg a saját különleges társát.', '2023-10-04 00:00:00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `deliverydetails`
--

CREATE TABLE `deliverydetails` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `deliveryBoyName` varchar(35) NOT NULL,
  `deliveryBoyPhoneNo` bigint(25) NOT NULL,
  `deliveryTime` int(200) NOT NULL COMMENT 'Time in minutes',
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `deliverydetails`
--

INSERT INTO `deliverydetails` (`id`, `orderId`, `deliveryBoyName`, `deliveryBoyPhoneNo`, `deliveryTime`, `dateTime`) VALUES
(1, 1, 'Dorián', 7036056778, 60, '2023-10-17 22:56:40'),
(2, 8, 'Anna', 703605677, 2, '2023-11-29 14:35:51');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `animalsId` int(21) NOT NULL,
  `itemQuantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `orderitems`
--

INSERT INTO `orderitems` (`id`, `orderId`, `animalsId`, `itemQuantity`) VALUES
(1, 1, 21, 7),
(2, 1, 30, 8),
(3, 1, 15, 1),
(4, 2, 2, 1),
(5, 2, 73, 1),
(6, 3, 5, 1),
(7, 4, 5, 1),
(8, 5, 1, 1),
(9, 6, 1, 1),
(10, 7, 1, 1),
(11, 8, 73, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orders`
--

CREATE TABLE `orders` (
  `orderId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipCode` int(21) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `amount` int(200) NOT NULL,
  `paymentMode` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=igen, 1=nem ',
  `orderStatus` enum('0','1','2','3','4','5','6') NOT NULL DEFAULT '0' COMMENT '0=Order Placed.\r\n1=Order Confirmed.\r\n2=Preparing your Order.\r\n3=Your order is on the way!\r\n4=Order Delivered.\r\n5=Order Denied.\r\n6=Order Cancelled.',
  `orderDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `orders`
--

INSERT INTO `orders` (`orderId`, `userId`, `address`, `zipCode`, `phoneNo`, `amount`, `paymentMode`, `orderStatus`, `orderDate`) VALUES
(2, 2, 'Erős János utca 5., Erős János utca 5.', 4545, 703605677, 1101, '0', '0', '2023-10-31 00:58:08'),
(3, 2, 'Forradalom utca 17., Forradalom utca 17.', 3343, 304170374, 650, '0', '0', '2023-11-12 23:52:43'),
(4, 2, 'Forradalom utca 17., Forradalom utca 17.', 3443, 304170374, 650, '0', '2', '2023-11-12 23:58:52'),
(5, 2, 'Erős János utca 5., Erős János utca 5.', 4545, 304170374, 1200, '0', '1', '2023-11-25 01:10:50'),
(6, 2, 'Forradalom utca 17., Forradalom utca 17.', 4545, 304170374, 1200, '0', '0', '2023-11-25 01:17:10'),
(7, 2, 'Erős János utca 5., Erős János utca 5.', 4433, 703605677, 1200, '0', '0', '2023-11-29 00:18:33'),
(8, 2, 'Erős János utca 5., Erős János utca 5.', 4433, 703605677, 1, '0', '3', '2023-11-29 00:29:50');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `sitedetail`
--

CREATE TABLE `sitedetail` (
  `tempId` int(11) NOT NULL,
  `systemName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `contact1` bigint(21) NOT NULL,
  `contact2` bigint(21) DEFAULT NULL COMMENT 'Optional',
  `address` text NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `sitedetail`
--

INSERT INTO `sitedetail` (`tempId`, `systemName`, `email`, `contact1`, `contact2`, `address`, `dateTime`) VALUES
(1, 'Állati Otthon', '', 0, 0, '', '2021-03-23 19:56:25');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(21) NOT NULL,
  `username` varchar(21) NOT NULL,
  `firstName` varchar(21) NOT NULL,
  `lastName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `userType` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=user\r\n1=admin',
  `password` varchar(255) NOT NULL,
  `joinDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `phone`, `userType`, `password`, `joinDate`) VALUES
(1, 'admin', 'admin', 'admin', 'admin@gmail.com', 111111111, '1', '$2y$10$AAfxRFOYbl7FdN17rN3fgeiPu/xQrx6MnvRGzqjVHlGqHAM4d9T1i', '2021-04-11 11:40:58'),
(2, 'Szekix16', 'Szekeres', 'Alex', 'szekix16@gmail.com', 703605677, '0', '$2y$10$Ysi793WTEVJeZ3ZGKrq/q.ITiYfMy2DKTsrON3PHUv.Ft5xfV/gX2', '2023-10-04 11:50:40'),
(3, 'szannab99', 'Szabó', 'Anna', 'szannab99@gmail.com', 302517622, '0', '$2y$10$4fggZoyNvtwpf60yF8TlLey8sN.dtHSnJQR4objwkInWGTX0YJmIS', '2023-10-09 00:13:00'),
(4, 'Mekk', 'Mekk', 'Elek', 'mekkelek@gamil.com', 6304170374, '0', '$2y$10$3uvuMAkbHJUm/7eKz6nxyerx0Hrp.4tTpLqisGqiq1r25p.LLtWJy', '2023-10-09 00:15:29');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `viewcart`
--

CREATE TABLE `viewcart` (
  `cartItemId` int(11) NOT NULL,
  `animalsId` int(11) NOT NULL,
  `itemQuantity` int(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `addedDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `viewcart`
--

INSERT INTO `viewcart` (`cartItemId`, `animalsId`, `itemQuantity`, `userId`, `addedDate`) VALUES
(33, 4, 1, 2, '2023-11-29 00:29:54'),
(34, 1, 1, 2, '2023-11-29 00:56:03');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `animals`
--
ALTER TABLE `animals`
  ADD PRIMARY KEY (`animalsId`);
ALTER TABLE `animals` ADD FULLTEXT KEY `animalsName` (`animalsName`,`animalsDesc`);

--
-- A tábla indexei `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categorieId`);
ALTER TABLE `categories` ADD FULLTEXT KEY `categorieName` (`categorieName`,`categorieDesc`);

--
-- A tábla indexei `deliverydetails`
--
ALTER TABLE `deliverydetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orderId` (`orderId`);

--
-- A tábla indexei `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- A tábla indexei `sitedetail`
--
ALTER TABLE `sitedetail`
  ADD PRIMARY KEY (`tempId`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`);

--
-- A tábla indexei `viewcart`
--
ALTER TABLE `viewcart`
  ADD PRIMARY KEY (`cartItemId`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `animals`
--
ALTER TABLE `animals`
  MODIFY `animalsId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT a táblához `categories`
--
ALTER TABLE `categories`
  MODIFY `categorieId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT a táblához `deliverydetails`
--
ALTER TABLE `deliverydetails`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT a táblához `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `sitedetail`
--
ALTER TABLE `sitedetail`
  MODIFY `tempId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `viewcart`
--
ALTER TABLE `viewcart`
  MODIFY `cartItemId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- Adatbázis: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- A tábla adatainak kiíratása `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"zh2\",\"table\":\"szavazat\"},{\"db\":\"zh2\",\"table\":\"opcio\"},{\"db\":\"opd\",\"table\":\"animals\"},{\"db\":\"profilepicture\",\"table\":\"user\"},{\"db\":\"raktar\",\"table\":\"termekek\"}]');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- A tábla adatainak kiíratása `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2023-12-05 11:33:40', '{\"Console\\/Mode\":\"collapse\",\"lang\":\"hu\"}');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- A tábla indexei `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- A tábla indexei `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- A tábla indexei `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- A tábla indexei `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- A tábla indexei `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- A tábla indexei `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- A tábla indexei `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- A tábla indexei `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- A tábla indexei `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- A tábla indexei `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- A tábla indexei `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- A tábla indexei `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- A tábla indexei `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- A tábla indexei `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- A tábla indexei `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- A tábla indexei `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- A tábla indexei `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Adatbázis: `profil`
--
CREATE DATABASE IF NOT EXISTS `profil` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `profil`;
--
-- Adatbázis: `profilepicture`
--
CREATE DATABASE IF NOT EXISTS `profilepicture` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `profilepicture`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user`
--

CREATE TABLE `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profilepicture` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `user`
--

INSERT INTO `user` (`username`, `password`, `profilepicture`) VALUES
('admin', 'admin', 'logosz.png'),
('alex', 'alex', NULL),
('anna', 'anna', NULL);
--
-- Adatbázis: `raktar`
--
CREATE DATABASE IF NOT EXISTS `raktar` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `raktar`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `termekek`
--

CREATE TABLE `termekek` (
  `nev` varchar(255) NOT NULL,
  `ár` int(11) NOT NULL,
  `Készleten` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `termekek`
--

INSERT INTO `termekek` (`nev`, `ár`, `Készleten`) VALUES
('', 0, 0);
--
-- Adatbázis: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
--
-- Adatbázis: `zh2`
--
CREATE DATABASE IF NOT EXISTS `zh2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `zh2`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `opcio`
--

CREATE TABLE `opcio` (
  `opcioId` int(11) NOT NULL,
  `opcioSzoveg` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- A tábla adatainak kiíratása `opcio`
--

INSERT INTO `opcio` (`opcioId`, `opcioSzoveg`) VALUES
(1, 'Szerintem attól lenne hatékonyabb az óra, ha több önálló feladatunk lenne'),
(2, 'Szerintem attól lenne hatékonyabb az óra, ha többet dolgoznánk közösen'),
(3, 'Szerintem attól lenne hatékonyabb az óra, ha több házi feladatot kapnánk');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `szavazat`
--

CREATE TABLE `szavazat` (
  `szavazatId` int(11) NOT NULL,
  `neptunKod` char(6) NOT NULL,
  `opcioId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- A tábla adatainak kiíratása `szavazat`
--

INSERT INTO `szavazat` (`szavazatId`, `neptunKod`, `opcioId`) VALUES
(1, 'MEKKEL', 1),
(2, 'MEKKEL', 3),
(3, 'MAKKMA', 2),
(4, 'MAKKMA', 3),
(9, 'BK28NS', 3),
(10, 'fggfgf', 1),
(11, '2323', 2),
(12, '332', 2),
(13, '3232', 1),
(14, '33', 1),
(15, '666666', 1),
(16, '555555', 1),
(17, 'ss4444', 2),
(18, '123456', 3),
(19, '654321', 2),
(20, '999999', 1),
(21, '121212', 3),
(22, '333333', 1);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `opcio`
--
ALTER TABLE `opcio`
  ADD PRIMARY KEY (`opcioId`);

--
-- A tábla indexei `szavazat`
--
ALTER TABLE `szavazat`
  ADD PRIMARY KEY (`szavazatId`),
  ADD KEY `opcioId` (`opcioId`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `opcio`
--
ALTER TABLE `opcio`
  MODIFY `opcioId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `szavazat`
--
ALTER TABLE `szavazat`
  MODIFY `szavazatId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `szavazat`
--
ALTER TABLE `szavazat`
  ADD CONSTRAINT `szavazat_ibfk_1` FOREIGN KEY (`opcioId`) REFERENCES `opcio` (`opcioId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
