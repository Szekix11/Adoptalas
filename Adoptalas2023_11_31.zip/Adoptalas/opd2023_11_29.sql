-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Nov 29. 01:04
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `opd`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `animals`
--

CREATE TABLE `animals` (
  `animalsId` int(12) NOT NULL,
  `animalsName` varchar(255) NOT NULL,
  `animalsNickname` varchar(255) DEFAULT NULL,
  `animalsPrice` int(12) NOT NULL,
  `animalsDesc` text NOT NULL,
  `animalsCategorieId` int(12) NOT NULL,
  `animalsPubDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `animals`
--

INSERT INTO `animals` (`animalsId`, `animalsName`, `animalsNickname`, `animalsPrice`, `animalsDesc`, `animalsCategorieId`, `animalsPubDate`) VALUES
(1, 'Keverék', 'Vackor', 1200, 'Státusz:Gazdit keres\r\nElvihető (előreláthatóan):2017. május 5. után bármikor\r\nKora:7 éves\r\nIvar:kan', 1, '2023-10-04 00:00:00'),
(2, 'Labrador Retriever', 'Buddy', 1100, 'A Labrador Retrieverek hűségesek és barátságosak. Jó háziállatok és családi kedvencek.', 1, '2023-10-04 00:00:00'),
(3, 'Pomerániai', 'Pommy', 1500, 'A Pomerániai kutyák aranyosak és élénkek. Kis méretük ellenére nagy személyiségűek.', 1, '2023-10-04 00:00:00'),
(4, 'Perzsa', 'Fluffy', 800, 'A Perzsa macskák csendesek és imádják a szeretetet. Szép hosszú szőrük van és kényeztetésre vágynak.', 2, '2023-10-04 00:00:00'),
(5, 'Orrnyúl', 'Bugsy', 650, 'A magyar óriás nyúlak szórakoztatóak és kíváncsiak. Szeretnek kutakodni és játékosak.', 4, '2023-10-04 00:00:00'),
(6, 'Kanári', 'Sunny', 200, 'A kanári madarak szépek és jókedvűek. Hangosan énekelnek és szórakoztatnak.', 5, '2023-10-04 00:00:00'),
(14, 'Bengáli Papagáj', 'Benny', 4800, 'A bengáli papagájok intelligensek és játékosak. Hangosan és szórakoztatóan énekelnek.', 5, '2023-10-04 00:00:00'),
(15, 'Cseles Csincsilla', 'Chilly', 3200, 'A cseles csincsillák aranyosak és puha bundájuk van. Könnyűszerrel nevelhetők és hűségesek.', 6, '2023-10-04 00:00:00'),
(33, 'Barna Papagáj', 'Browny', 3900, 'A barna papagájok színesek és jókedvűek. Hangosan énekelnek és jó társak.', 5, '2023-10-04 00:00:00'),
(40, 'Tacsi', 'Wiener', 1500, 'A tacsi kiskutyák aranyosak és játékosak. Jó választás, ha kis lakásban élsz.', 1, '2023-10-04 00:00:00'),
(45, 'Tengerimalac', 'Whiskers', 350, 'A tengerimalacok cselesek és aranyosak. Könnyen tarthatók.', 6, '2023-10-04 00:00:00'),
(52, 'Lila Papagáj', 'Purpley', 4800, 'A lila papagájok színesek és jókedvűek. Hangosan énekelnek és szórakoztatnak.', 5, '2023-10-04 00:00:00'),
(69, 'Dobermann', 'Doby', 1, 'Kiváló házőrzők és játékos, vidám kutyák.', 1, '2023-10-23 02:21:16'),
(70, 'Puli', 'Puffy', 1, 'Ők az ember legállhatatosabb társai. Kiváló házőrzők és játékos, vidám kutyák.', 1, '2023-10-23 02:22:52'),
(71, 'Magyar Vizsla', 'Vizzy', 2, 'Barátságos gazdi szerető kutyák.', 1, '2023-10-23 23:51:38'),
(72, 'Barna husky', 'Husky', 1, 'Barátságos,jó nevelt kutya.', 1, '2023-10-23 23:57:01'),
(73, 'Bengáli macska', 'Benny Jr.', 1, 'Barátságos fiatal kis cica.', 2, '2023-10-23 23:59:16'),
(74, 'Tacskómacska', 'Wiener Jr.', 1, 'Barátságos, jó nevelt cica.', 2, '2023-10-24 00:00:30'),
(75, 'Alpaka', 'Fluffy Jr.', 1, 'Alpakáéánk barátságos szertő gazdira vágyik.', 8, '2023-10-24 00:05:34');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `categories`
--

CREATE TABLE `categories` (
  `categorieId` int(12) NOT NULL,
  `categorieName` varchar(255) NOT NULL,
  `categorieDesc` text NOT NULL,
  `categorieCreateDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `categories`
--

INSERT INTO `categories` (`categorieId`, `categorieName`, `categorieDesc`, `categorieCreateDate`) VALUES
(1, 'Kutyáink', 'A legjobb barátok. A kutya az ember leghűségesebb társa. Kedvenc négylábú kutyáink különböző méretűek és fajtájúak, de mindegyikük imádnivaló és várja, hogy egy szerető otthonba kerüljön.', '2023-10-04 00:00:00'),
(2, 'Macskáink', 'Különböző macska fajták várják, hogy otthonra találjanak. Legyen szőrös barátja, és élvezze a macskák társaságát. Mindegyik macska egyedi személyiséggel rendelkezik, és hűséges társa lehet.', '2023-10-04 00:00:00'),
(4, 'Nyúlak', 'A nyulak csendes és bájos háziállatok. Sokféle nyúlfajta közül választhat, és mindegyikük hűséges társ lehet. A nyúlok ápolása és etetése egyszerű, és örömüket leli a játékban.', '2023-10-04 00:00:00'),
(5, 'Madarak', 'A madarak csodálatos és színes lények. Legyen szárnyas barátja, és hallgassa meg éneküket minden nap. A különböző madárfajták szépségükkel és egyediségükkel elvarázsolják majd önt.', '2023-10-04 00:00:00'),
(6, 'Kisemlőseink', 'Az apró kisemlősök különleges örömet hoznak az otthonába. Például hörcsögök, patkányok és csincsillák szép, kis háziállatok lehetnek. Találja meg a tökéletes kisemlőst, hogy elkényeztesse őket.', '2023-10-04 00:00:00'),
(8, 'Egyebek', 'Nem csak a hagyományos háziállatok érnek, sok más különleges és szokatlan állat is várja, hogy örökbefogadják őket. Fedezze fel a különleges állatok világát, és találja meg a saját különleges társát.', '2023-10-04 00:00:00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contact`
--

CREATE TABLE `contact` (
  `contactId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `orderId` int(21) NOT NULL DEFAULT 0 COMMENT 'If problem is not related to the order then order id = 0',
  `message` text NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contact`
--

INSERT INTO `contact` (`contactId`, `userId`, `email`, `phoneNo`, `orderId`, `message`, `time`) VALUES
(1, 2, 'szekix16@gmail.com', 5362517622, 1, 'Romlott volt a sajt.', '2023-10-04 15:04:17');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contactreply`
--

CREATE TABLE `contactreply` (
  `id` int(21) NOT NULL,
  `contactId` int(21) NOT NULL,
  `userId` int(23) NOT NULL,
  `message` text NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contactreply`
--

INSERT INTO `contactreply` (`id`, `contactId`, `userId`, `message`, `datetime`) VALUES
(4, 1, 2, '500 ft kupon', '2023-10-08 23:36:21');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `deliverydetails`
--

CREATE TABLE `deliverydetails` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `deliveryBoyName` varchar(35) NOT NULL,
  `deliveryBoyPhoneNo` bigint(25) NOT NULL,
  `deliveryTime` int(200) NOT NULL COMMENT 'Time in minutes',
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `deliverydetails`
--

INSERT INTO `deliverydetails` (`id`, `orderId`, `deliveryBoyName`, `deliveryBoyPhoneNo`, `deliveryTime`, `dateTime`) VALUES
(1, 1, 'Dorián', 7036056778, 60, '2023-10-17 22:56:40');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `animalsId` int(21) NOT NULL,
  `itemQuantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `orderitems`
--

INSERT INTO `orderitems` (`id`, `orderId`, `animalsId`, `itemQuantity`) VALUES
(1, 1, 21, 7),
(2, 1, 30, 8),
(3, 1, 15, 1),
(4, 2, 2, 1),
(5, 2, 73, 1),
(6, 3, 5, 1),
(7, 4, 5, 1),
(8, 5, 1, 1),
(9, 6, 1, 1),
(10, 7, 1, 1),
(11, 8, 73, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orders`
--

CREATE TABLE `orders` (
  `orderId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipCode` int(21) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `amount` int(200) NOT NULL,
  `paymentMode` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=igen, 0=nem ',
  `orderStatus` enum('0','1','2','3','4','5','6') NOT NULL DEFAULT '0' COMMENT '0=Order Placed.\r\n1=Order Confirmed.\r\n2=Preparing your Order.\r\n3=Your order is on the way!\r\n4=Order Delivered.\r\n5=Order Denied.\r\n6=Order Cancelled.',
  `orderDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `orders`
--

INSERT INTO `orders` (`orderId`, `userId`, `address`, `zipCode`, `phoneNo`, `amount`, `paymentMode`, `orderStatus`, `orderDate`) VALUES
(1, 2, 'Szeged, Erős utca 5', 232323, 3334434232, 38711, '0', '2', '2023-10-04 15:54:28'),
(2, 2, 'Erős János utca 5., Erős János utca 5.', 4545, 703605677, 1101, '0', '0', '2023-10-31 00:58:08'),
(3, 2, 'Forradalom utca 17., Forradalom utca 17.', 3343, 304170374, 650, '0', '0', '2023-11-12 23:52:43'),
(4, 2, 'Forradalom utca 17., Forradalom utca 17.', 3443, 304170374, 650, '0', '0', '2023-11-12 23:58:52'),
(5, 2, 'Erős János utca 5., Erős János utca 5.', 4545, 304170374, 1200, '0', '1', '2023-11-25 01:10:50'),
(6, 2, 'Forradalom utca 17., Forradalom utca 17.', 4545, 304170374, 1200, '0', '0', '2023-11-25 01:17:10'),
(7, 2, 'Erős János utca 5., Erős János utca 5.', 4433, 703605677, 1200, '0', '0', '2023-11-29 00:18:33'),
(8, 2, 'Erős János utca 5., Erős János utca 5.', 4433, 703605677, 1, '0', '0', '2023-11-29 00:29:50');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `sitedetail`
--

CREATE TABLE `sitedetail` (
  `tempId` int(11) NOT NULL,
  `systemName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `contact1` bigint(21) NOT NULL,
  `contact2` bigint(21) DEFAULT NULL COMMENT 'Optional',
  `address` text NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `sitedetail`
--

INSERT INTO `sitedetail` (`tempId`, `systemName`, `email`, `contact1`, `contact2`, `address`, `dateTime`) VALUES
(1, 'Állati Otthon', '', 0, 0, '', '2021-03-23 19:56:25');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(21) NOT NULL,
  `username` varchar(21) NOT NULL,
  `firstName` varchar(21) NOT NULL,
  `lastName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `userType` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=user\r\n1=admin',
  `password` varchar(255) NOT NULL,
  `joinDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `phone`, `userType`, `password`, `joinDate`) VALUES
(1, 'admin', 'admin', 'admin', 'admin@gmail.com', 111111111, '1', '$2y$10$AAfxRFOYbl7FdN17rN3fgeiPu/xQrx6MnvRGzqjVHlGqHAM4d9T1i', '2021-04-11 11:40:58'),
(2, 'Szekix16', 'Szekeres', 'Alex', 'szekix16@gmail.com', 703605677, '0', '$2y$10$Ysi793WTEVJeZ3ZGKrq/q.ITiYfMy2DKTsrON3PHUv.Ft5xfV/gX2', '2023-10-04 11:50:40'),
(3, 'szannab99', 'Szabó', 'Anna', 'szannab99@gmail.com', 302517622, '0', '$2y$10$4fggZoyNvtwpf60yF8TlLey8sN.dtHSnJQR4objwkInWGTX0YJmIS', '2023-10-09 00:13:00'),
(4, 'Mekk', 'Mekk', 'Elek', 'mekkelek@gamil.com', 6304170374, '0', '$2y$10$3uvuMAkbHJUm/7eKz6nxyerx0Hrp.4tTpLqisGqiq1r25p.LLtWJy', '2023-10-09 00:15:29');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `viewcart`
--

CREATE TABLE `viewcart` (
  `cartItemId` int(11) NOT NULL,
  `animalsId` int(11) NOT NULL,
  `itemQuantity` int(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `addedDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `viewcart`
--

INSERT INTO `viewcart` (`cartItemId`, `animalsId`, `itemQuantity`, `userId`, `addedDate`) VALUES
(33, 4, 1, 2, '2023-11-29 00:29:54'),
(34, 1, 1, 2, '2023-11-29 00:56:03');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `animals`
--
ALTER TABLE `animals`
  ADD PRIMARY KEY (`animalsId`);
ALTER TABLE `animals` ADD FULLTEXT KEY `animalsName` (`animalsName`,`animalsDesc`);

--
-- A tábla indexei `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categorieId`);
ALTER TABLE `categories` ADD FULLTEXT KEY `categorieName` (`categorieName`,`categorieDesc`);

--
-- A tábla indexei `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contactId`);

--
-- A tábla indexei `contactreply`
--
ALTER TABLE `contactreply`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `deliverydetails`
--
ALTER TABLE `deliverydetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orderId` (`orderId`);

--
-- A tábla indexei `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- A tábla indexei `sitedetail`
--
ALTER TABLE `sitedetail`
  ADD PRIMARY KEY (`tempId`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`);

--
-- A tábla indexei `viewcart`
--
ALTER TABLE `viewcart`
  ADD PRIMARY KEY (`cartItemId`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `animals`
--
ALTER TABLE `animals`
  MODIFY `animalsId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT a táblához `categories`
--
ALTER TABLE `categories`
  MODIFY `categorieId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT a táblához `contact`
--
ALTER TABLE `contact`
  MODIFY `contactId` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `contactreply`
--
ALTER TABLE `contactreply`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `deliverydetails`
--
ALTER TABLE `deliverydetails`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT a táblához `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `sitedetail`
--
ALTER TABLE `sitedetail`
  MODIFY `tempId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `viewcart`
--
ALTER TABLE `viewcart`
  MODIFY `cartItemId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
