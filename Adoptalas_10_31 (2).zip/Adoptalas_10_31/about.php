<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Szekeres Alex Patrik, Merza Nikolett Éva, Takács Lilla">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Örökbefogadás">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

    <title>Rólunk</title>
    <link rel = "icon" href ="img/logo.jpg" type = "image/x-icon">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
  <head>
  <style>
    .carousel-background {
    background-image: url('img/slide.jpg');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    width: 100%;
    height: 100vh;
}

  </style>
   

  </head>
  <body>
    
  <?php include 'partials/_dbconnect.php';?>
  <?php include 'partials/_nav.php';?>
  
      <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">
        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>
        
          <!-- Slide 1 -->
          <div class="carousel-item active">
            <div class="carousel-background"></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Üdvözöllek a <span>Állati Otthon oldalán</span></h2>
                <a href="index.php" class="btn-get-started animate__animated animate__fadeInUp scrollto">Kezd el az örökbefogadást</a>
              </div>
            </div>
          </div>
          

       

       

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

  

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>Rólunk</h2>
        </div>
        <article id="post-219" class="post-219 page type-page status-publish hentry">
          
<h1>Az alapítvány</h1>
<div class="text">
<blockquote><p><strong>Alapítványunk tizennégy éve dolgozik az utcára kerülő, árva és sérült kutyák gyógyításáért, örökbefogadási esélyeinek növeléséért, gazdához juttatásáért. &nbsp;</strong><br>
A kuratórium tagjai munkájukat elkötelezettségből, tiszteletdíj nélkül az állatok iránt érzett szeretetből végzik. Tevékenységünket, gazdálkodásunkat az Alapítvány Felügyelőbizottsága ellenőrzi, akik szintén társadalmi munkában dolgoznak.</p>
<p><span ><strong>De kik is vagyunk, és mit csinálunk?</strong></span></p>
<p>Ismerj meg minket jobban!</p>
<p>Már 14 éve, hogy létrehoztuk a Állati Otthon. Hétköznapi állatbarátokként mentünk ki az útra, hogy megismerjük munkájukat és megtudjuk, miben segíthetünk. Szerencsénk volt, mert Dr Kozma Tamás vezető állatorvos fogadott minket, és részletesen elmondta, miben számítanának a közreműködésünkre.</p>
<p>Önként vállalt feladataink már az első évtől sem merültek ki abban, hogy kutyákat mentettünk és sikeres örökbefogadó napokat szerveztünk a telepen.</p>
<ul>
<li>Megvásároltuk az első, színes, orvosi ultrahang készüléket, hogy a betegségeket, sérüléseket időben diagnosztizálhassák.</li>
<li>Valamennyi külső kennelt hőszigetelt ipari gumifelülettel láttuk el, hogy ne fázzanak a kutyák a beton aljzaton</li>
<li>Korszerű, elektromos kutya-futópadot vásároltunk, hogy a nagy mozgásigényű kutyáknak a kis hely ellenére is mozgási lehetőséget biztosítsunk.</li>
<li>Folyamatosan, igény szerint állatgyógyszereket betegségek azonosításához szükséget teszteket, speciális tápokat vásároltunk.</li>
<li>A kölyökkutyák számára ipari infravörös melegítőket adtunk át, hogy megelőzhessék a kicsik kihűlését.</li>
<li>Hőszigetelt kutyaházakat vásároltunk</li>
<li>Fontos vállalásunk, a túlszaporulat megelőzése érdekében az állatok ivartalanítása. Ennek érdekében valamennyi, az menhelyünről magánszemély által örökbe fogadott kutya gazdájának 2019-ig ingyenes ivartalanítási lehetőséget adtunk, melyet szerződött állatorvosaink végeztek el. (azóta a telep állatorvosai végzik az ivartalanításokat)</li>
</ul>
<p>2019 óta valamennyi 7 hónapnál fiatalabb, az örökbe fogadáskor még nem ivartalanítható kutya ivartalanítását ingyenesen végeztetjük. Az örökbefogadáskor kapott kuponunkkal jelentkezhet a gazdi nálunk, a kutya 7 hónapos korában és mi, alapítványunk költségén megoldjuk az ivartalanítást.</p>
<p>Persze legfontosabb vállalt feladatunk azóta is, a sérült, elgázolt, a telepen nem gyógyítható kutyák gondozásba vétele: Jelenleg is, szinte valamennyi ortopéd sebészeti műtétet alapítványunk végeztet el. Természetesen ezek a kutyák már nem kerülnek vissza a telepre, hanem a hosszú hónapokig tartó rehabilitációjuk, teljes fizikai és lelki gyógyulásuk után is tovább gondozzuk őket, amig megfelelő örökbe adókat találunk számukra.</p>
<p>Alapítványunk folyamatosan veszi gondozásába azokat a kutyákat, akik idősek, vagy már hosszú ideje: akár több éve a telepen várták reménytelenül örökbefogadójukat. hozzánk kerülnek csonkolt lábú viselkedés zavaros kutyák is, akik a szokásosnál is több törődést, szakmai segítséget igényelnek. Büszkén mondhatjuk, hogy közülük is nagyon sokat adunk sikeresen örökbe… persze többen: 10, 12, 14 évesek várják még nálunk új gazdijaikat. Ha<span> megnézitek az örökbe adott kutyákat</a> </span>láthatjátok, hogy hogyan és kiknek adunk kutyákat örökbe.</p>
<p>Egy idő után úgy éreztük, hogy nem csupán az a fontos, hogy az Illatos útról mentsünk kutyákat, hanem hogy megelőzzük azt, hogy oda kerüljenek.</p>

<p>Amikor nagy a baj, lehetőségeink szerint más alapítványoknak, állatbarátoknak is segítünk</p>
<ul>
<li>Az árvíz idején, a bajba jutott menhelyek javára indított jótékonysági akciónkkal és az általunk szervezett koncert segítségével több millió forintot és táp adományt gyűjtöttünk, melyeket átláthatóan az erre leginkább rászoruló alapítványok között osztottunk szét.</li>
<li>Néhány éve, egy másik állatvédő szervezettel indított közös kampányunkkal több mint 500 kutyaházat gyűjtöttünk, illetve vásároltunk, melyeket még a nagy hidegek előtt eljuttattunk a rászoruló menhelyeknek.</li>
<li>Mikrochip leolvasó hálózatunk bővítése kapcsán egyik mobil szolgáltatót és a NÉBIH-et bevonva, laptopokat és mikrochip leolvasókat juttattunk el állatvédő szervezetekhez.</li>
<li>Évek óta ajánlunk ingyenes jogsegélyt azoknak a felelős állatbarátoknak, akik a hőségben a kocsiban hagyott kutyákat úgy mentenék meg, hogy betörik az autó ablakát.</li>
</ul>

</p>
</div>
<br class="clear">
</article>


    </section><!-- End About Us Section -->

    <!-- ======= Counts Section ======= -->
    <section class="counts section-bg">
      <div class="container">

        <div class="row no-gutters">

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-simple-smile"></i>
              <span data-toggle="counter-up">560</span>
              <p><strong>Örökbefogadóink száma</strong></p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-document-folder"></i>
              <span data-toggle="counter-up">1201</span>
              <p><strong>Eddigi megmentett állataink száma</strong></p>
            </div>
          </div>

         

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-users-alt-5"></i>
              <span data-toggle="counter-up">15</span>
              <p><strong>Alkalmazottak száma</strong></p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-users-alt-5"></i>
              <span data-toggle="counter-up">230</span>
              <p><strong>Támogatóink száma</strong></p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

  </main>

  <?php include 'partials/_footer.php';?> 

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/jquery-sticky/jquery.sticky.js"></script>
    <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counterup/counterup.min.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>


  </body>
</html>
